﻿
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text
Imports Newtonsoft.Json


Module CustomHotKeys

    Public hotKeys_ModuleVersion As String = "1.0.0.0"
    Public mainFormReference As Form    ' On Your Main Form Load Event, assign it to this variable. (i.e. Form1 in most cases, but you could have renamed it)

    Public hotKeys_aboutText As String = "Hotkeys - Version:" & hotKeys_ModuleVersion & vbCrLf & vbCrLf &
    "Module for global Hotkeys and custom actions" & vbCrLf & vbCrLf &
    ".NET Framework 4.5.1+." & vbCrLf & vbCrLf &
    "Features:" & vbCrLf &
    "• Supports global hotkeys" & vbCrLf &
    "• Allows importing and exporting via JSON"

    Public Const WM_HOTKEY As Integer = &H312

    Public Class NativeMethods
        <DllImport("user32.dll")>
        Public Shared Function RegisterHotKey(hWnd As IntPtr, id As Integer, fsModifiers As UInteger, vk As UInteger) As Boolean
        End Function

        <DllImport("user32.dll")>
        Public Shared Function UnregisterHotKey(hWnd As IntPtr, id As Integer) As Boolean
        End Function

        <Flags>
        Public Enum Modifiers As UInteger
            None = 0
            Alt = 1
            Control = 2
            Shift = 4
            Win = 8
        End Enum
    End Class


    ' Track Which Hotkeys are Mapped
    Public hotkeyIdCounter As Integer = 0
    Public hotkeyIdMap As New Dictionary(Of Integer, Action)
    Public HotkeyMap As New Dictionary(Of HotkeyKey, Action)
    Public hotkeyEnabledMap As New Dictionary(Of Action, Boolean)

    Public Structure HotkeyKey
        Public Modifiers As Keys
        Public Key As Keys

        Public Sub New(mods As Keys, k As Keys)
            Modifiers = mods
            Key = k
        End Sub

        Public Overrides Function GetHashCode() As Integer
            Return Modifiers.GetHashCode() Xor Key.GetHashCode()
        End Function

        Public Overrides Function Equals(obj As Object) As Boolean
            Try
                If TypeOf obj Is HotkeyKey Then
                    Dim other = CType(obj, HotkeyKey)
                    Return Me.Modifiers = other.Modifiers AndAlso Me.Key = other.Key
                End If
                Return False
            Catch ex As Exception
                Return False
            End Try
        End Function
    End Structure





    ' Mapping to Function Names
    ' ###############################################
    ' THESE ARE DEMOS - AMEND WITH YOUR OWN FUNCTIONS
    ' ###############################################
    Public functionToHotkeyMap As New Dictionary(Of Action, HotkeyKey)
    Public actionDict As New Dictionary(Of String, Action) From {
        {"Action1", AddressOf Action1},
        {"Action2", AddressOf Action2},
        {"Action3", AddressOf Action3}
    }

    Sub Action1()
        Debug.WriteLine("Action 1 executed with hotkey")
    End Sub

    Sub Action2()
        Debug.WriteLine("Action 2 executed with hotkey")
    End Sub

    Sub Action3()
        Debug.WriteLine("Action 3 executed with hotkey")
    End Sub





    Public Async Function ExportHotkeysAsync(rows As DataGridViewRowCollection, Optional outputPath As String = Nothing) As Task
        Try
            If String.IsNullOrEmpty(outputPath) Then
                outputPath = Path.Combine(Application.StartupPath, "hotkeys_BACKUP.json")
            End If
            Dim exportList As New List(Of Object)
            For Each row As DataGridViewRow In rows
                If Not row.IsNewRow AndAlso
                   row.Cells("ActionFunction").Value IsNot Nothing AndAlso
                   row.Cells("KeyCombination").Value IsNot Nothing Then

                    exportList.Add(New With {
                        .Function = row.Cells("ActionFunction").Value.ToString(),
                        .KeyCombo = row.Cells("KeyCombination").Value.ToString()
                    })
                End If
            Next

            Dim json As String = JsonConvert.SerializeObject(exportList, Formatting.Indented)
            Using writer As New StreamWriter(outputPath, False, Encoding.UTF8)
                Await writer.WriteAsync(json)
            End Using
            Debug.WriteLine($"[Hotkey Save] Saved to: {outputPath}")
        Catch ex As Exception
            MessageBox.Show("Error saving hotkeys:" & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function



    '                                           hotKeyToAssign As Action(Of Keys, Keys, Action),
    Public Async Function ImportHotkeysAsync(owner As IWin32Window,
                                           actionDict As Dictionary(Of String, Action),
                                           hotKeyToAssign As Action(Of Keys, Keys, Action),
                                           Optional dataGridRows As DataGridViewRowCollection = Nothing) As Task
        Try

            Dim ofd As New OpenFileDialog With {.Filter = "JSON Files|*.json"}
            If ofd.ShowDialog(owner) <> DialogResult.OK Then Exit Function

            Dim json = File.ReadAllText(ofd.FileName)
            Dim importList = JsonConvert.DeserializeObject(Of List(Of Dictionary(Of String, String)))(json)

            For Each item In importList
                Try
                    If Not item.ContainsKey("KeyCombo") OrElse Not item.ContainsKey("Function") Then Continue For

                    Dim keyParts = item("KeyCombo").Split(" + ")
                    Dim modifiers As Keys = Keys.None
                    Dim key As Keys = Keys.None

                    If keyParts.Contains("Ctrl") Then modifiers = modifiers Or Keys.Control
                    If keyParts.Contains("Alt") Then modifiers = modifiers Or Keys.Alt
                    If keyParts.Contains("Shift") Then modifiers = modifiers Or Keys.Shift

                    Dim keyName As String = keyParts.Last().Trim()

                    If keyName.Length = 1 AndAlso Char.IsDigit(keyName(0)) Then
                        keyName = "D" & keyName
                    End If

                    key = CType([Enum].Parse(GetType(Keys), keyName, True), Keys)

                    If actionDict.ContainsKey(item("Function")) Then
                        Dim action = actionDict(item("Function"))
                        hotKeyToAssign(modifiers, key, action)
                    Else
                        MessageBox.Show(owner, $"Unknown function '{item("Function")}' in import file.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                Catch innerEx As Exception
                    MessageBox.Show(owner, "Error processing item in the import file: " & innerEx.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            Next

        Catch ex As Exception
            MessageBox.Show(owner, "Error occurred importing hotkeys:" & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function


    Public Function GetDisplayKeyText(key As Keys) As String
        If key >= Keys.D0 AndAlso key <= Keys.D9 Then
            Return (key - Keys.D0).ToString() ' D1 -> "1"
        ElseIf key >= Keys.NumPad0 AndAlso key <= Keys.NumPad9 Then
            Return "_NUMPAD" & (key - Keys.NumPad0).ToString()
        Else
            Return key.ToString() ' F1, A, B, etc.
        End If
    End Function


    Public Function GetKeyComboText(hk As HotkeyKey) As String
        Dim parts As New List(Of String)
        If (hk.Modifiers And Keys.Control) = Keys.Control Then parts.Add("Ctrl")
        If (hk.Modifiers And Keys.Alt) = Keys.Alt Then parts.Add("Alt")
        If (hk.Modifiers And Keys.Shift) = Keys.Shift Then parts.Add("Shift")
        parts.Add(GetDisplayKeyText(hk.Key)) ' <- Use your user-friendly text
        Return String.Join(" + ", parts)
    End Function


    Public Sub AssignHotkey(ByRef passedComboboxFuncList As ComboBox, ByRef passedDataGid As DataGridView, ByRef mainForm As Form, modifiers As Keys, key As Keys, action As Action)

        Dim modValue As UInteger = 0
        If (modifiers And Keys.Control) = Keys.Control Then modValue = modValue Or NativeMethods.Modifiers.Control
        If (modifiers And Keys.Alt) = Keys.Alt Then modValue = modValue Or NativeMethods.Modifiers.Alt
        If (modifiers And Keys.Shift) = Keys.Shift Then modValue = modValue Or NativeMethods.Modifiers.Shift

        ' Confirm at least 1 x modifier key was used
        If modifiers = Keys.None Then
            MessageBox.Show("Must use at least one modifier key (Ctrl, Alt, Shift).", "Modifier Missing", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim newHotkey As New HotkeyKey(modifiers, key)
        Dim existingComboText As String = ""


        If HotkeyMap.ContainsKey(newHotkey) Then
            Dim existingAction = HotkeyMap(newHotkey)

            ' 1. Check for Conflicting Hotkeys 
            If existingAction.Equals(action) Then
                Dim existingFuncName = actionDict.FirstOrDefault(Function(kvp) kvp.Value = existingAction).Key
                existingComboText = GetKeyComboText(newHotkey)
                MessageBox.Show($"The key combination [{existingComboText}] {vbCrLf}is already assigned to '{existingFuncName}'.", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub ' No need to reassign
            End If

            ' CASE 2: Conflict with different action
            Dim existingFuncNameConflict = actionDict.FirstOrDefault(Function(kvp) kvp.Value = existingAction).Key
            Dim newFuncName = actionDict.FirstOrDefault(Function(kvp) kvp.Value = action).Key
            Dim existingComboTextConflict = GetKeyComboText(newHotkey)

            Dim result = MessageBox.Show(
$"CONFIRM:{vbCrLf}The key combination [{existingComboTextConflict}] {vbCrLf}is already assigned to '{existingFuncNameConflict}'.{vbCrLf}{vbCrLf}" &
$"Do you want to reassign it to '{newFuncName}' instead?{vbCrLf}{vbCrLf}" &
$"Note:{vbCrLf}This will remove '{existingFuncNameConflict}' from the list.",
                "Note",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            )

            If result = DialogResult.No Then Exit Sub

            Dim existingId = hotkeyIdMap.FirstOrDefault(Function(kvp) kvp.Value = existingAction).Key
            If existingId <> 0 Then
                NativeMethods.UnregisterHotKey(mainForm.Handle, existingId)
                hotkeyIdMap.Remove(existingId)
            End If
            functionToHotkeyMap.Remove(existingAction)
            HotkeyMap.Remove(newHotkey)
        End If


        ' 2. Unregister any old key combo for this function
        If functionToHotkeyMap.ContainsKey(action) Then
            Dim oldHotkey = functionToHotkeyMap(action)
            Dim oldId = hotkeyIdMap.FirstOrDefault(Function(kvp) kvp.Value = action).Key
            Dim oldKeyCombination = GetKeyComboText(oldHotkey)
            Dim newKeyCombination = GetKeyComboText(newHotkey)

            Dim result = MessageBox.Show(
$"The function '{actionDict.FirstOrDefault(Function(kvp) kvp.Value = action).Key}'{vbCrLf}is already assigned to hotkey: [{oldKeyCombination}].{vbCrLf}{vbCrLf}" &
$"Reassign to hotkey: [{newKeyCombination}]?",
                "Note",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            )

            If result = DialogResult.No Then
                Exit Sub
            End If

            If oldId <> 0 Then
                NativeMethods.UnregisterHotKey(mainForm.Handle, oldId)
                hotkeyIdMap.Remove(oldId)
            End If
            HotkeyMap.Remove(oldHotkey)
            functionToHotkeyMap.Remove(action)
        End If

        ' 3. Register the new hotkey
        hotkeyIdCounter += 1

        Dim success
        Try
            success = NativeMethods.RegisterHotKey(mainForm.Handle, hotkeyIdCounter, modValue, CUInt(key))
        Catch ex As Exception
            MessageBox.Show($"Failed to register hotkey: {modifiers} + {key}.{vbCrLf}{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        If success Then
            HotkeyMap(newHotkey) = action
            functionToHotkeyMap(action) = newHotkey
            hotkeyIdMap(hotkeyIdCounter) = action
            hotkeyEnabledMap(action) = True ' Default to enabled
            Debug.WriteLine($"[SUCCESS] Assigned GLOBAL hotkey: {modifiers} + {key}")
            UpdateHotkeyDisplay(passedDataGid, passedComboboxFuncList.Text)
        Else
            Debug.WriteLine($"[FAILED] Could not assign GLOBAL hotkey: {modifiers} + {key}")
        End If
    End Sub


    Public Sub UpdateHotkeyDisplay(ByRef passedDataGridView As DataGridView, Optional selectedFuncName As String = Nothing)
        Try
            passedDataGridView.Rows.Clear()
            For Each kvp In HotkeyMap
                Try
                    Dim combo As String = GetKeyComboText(kvp.Key)
                    Dim funcName As String = actionDict.FirstOrDefault(Function(p) p.Value = kvp.Value).Key
                    Dim enabled As Boolean = True
                    If hotkeyEnabledMap.ContainsKey(kvp.Value) Then
                        enabled = hotkeyEnabledMap(kvp.Value)
                    End If
                    passedDataGridView.Rows.Add(funcName, combo, enabled)
                Catch ex As Exception
                    MessageBox.Show("Error processing hotkey: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            Next
            ' Reselect the previously selected function, if provided
            If Not String.IsNullOrEmpty(selectedFuncName) Then
                Try
                    For Each row As DataGridViewRow In passedDataGridView.Rows
                        If row.Cells("ActionFunction").Value?.ToString() = selectedFuncName Then
                            row.Selected = True
                            passedDataGridView.CurrentCell = row.Cells(0) ' Ensure focus
                            Exit For
                        End If
                    Next
                Catch ex As Exception
                    MessageBox.Show("Error selecting previous function: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            End If
        Catch ex As Exception
            MessageBox.Show("Unexpected error updating hotkey display: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Public Sub FilterDataGridView(ByRef passedDataGrid As DataGridView, ByVal searchTerm As String, Optional caseInsensitive As Boolean = False)
        Try
            searchTerm = searchTerm.Trim()

            ' If search term is empty, show all rows
            If String.IsNullOrEmpty(searchTerm) Then
                Try
                    For Each row As DataGridViewRow In passedDataGrid.Rows
                        row.Visible = True
                    Next
                Catch ex As Exception
                    MessageBox.Show("An error occurred while resetting rows: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
                Return
            End If

            If caseInsensitive Then searchTerm = searchTerm.ToLower()
            For Each row As DataGridViewRow In passedDataGrid.Rows
                Try
                    If Not row.IsNewRow Then
                        Dim actionValue As String = If(row.Cells("ActionFunction").Value?.ToString(), "")
                        Dim keyComboValue As String = If(row.Cells("KeyCombination").Value?.ToString(), "")

                        If caseInsensitive Then
                            actionValue = actionValue.ToLower()
                            keyComboValue = keyComboValue.ToLower()
                        End If

                        If actionValue.Contains(searchTerm) OrElse keyComboValue.Contains(searchTerm) Then
                            row.Visible = True
                        Else
                            row.Visible = False
                        End If
                    End If
                Catch exRow As Exception
                    MessageBox.Show("Error processing a row: " & exRow.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try
            Next

        Catch exOuter As Exception
            MessageBox.Show("Error occurred filtering the DataGridView:" & vbCrLf & exOuter.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Public Sub Sub_ToggleHotkey(ByRef mainForm As Form, action As Action, enable As Boolean)
        Try
            If Not functionToHotkeyMap.ContainsKey(action) Then Return

            Dim hotkey = functionToHotkeyMap(action)
            Dim id = hotkeyIdMap.FirstOrDefault(Function(kvp) kvp.Value = action).Key

            If enable Then
                ' Re-register the hotkey
                Try
                    Dim modValue As UInteger = 0
                    If (hotkey.Modifiers And Keys.Control) = Keys.Control Then modValue = modValue Or NativeMethods.Modifiers.Control
                    If (hotkey.Modifiers And Keys.Alt) = Keys.Alt Then modValue = modValue Or NativeMethods.Modifiers.Alt
                    If (hotkey.Modifiers And Keys.Shift) = Keys.Shift Then modValue = modValue Or NativeMethods.Modifiers.Shift

                    hotkeyIdCounter += 1
                    If NativeMethods.RegisterHotKey(mainForm.Handle, hotkeyIdCounter, modValue, CUInt(hotkey.Key)) Then
                        hotkeyIdMap(hotkeyIdCounter) = action
                        hotkeyEnabledMap(action) = True
                        Debug.WriteLine($"Hotkey for {action.Method.Name} ENABLED")
                    Else
                        MessageBox.Show($"Failed to enable hotkey for {action.Method.Name}.", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    End If
                Catch ex As Exception
                    MessageBox.Show($"Error occurred enabling hotkey for {action.Method.Name}:{vbCrLf}{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            Else
                ' Unregister
                Try
                    If id <> 0 Then
                        NativeMethods.UnregisterHotKey(mainForm.Handle, id)
                        hotkeyIdMap.Remove(id)
                        hotkeyEnabledMap(action) = False
                        Debug.WriteLine($"Hotkey for {action.Method.Name} DISABLED")
                    End If
                Catch ex As Exception
                    MessageBox.Show($"Error occurred disabling hotkey for {action.Method.Name}:{vbCrLf}{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

        Catch ex As Exception
            MessageBox.Show($"Unexpected error in Sub_ToggleHotkey: {vbCrLf}{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Module
