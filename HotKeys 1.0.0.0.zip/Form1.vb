﻿



Public Class Form1


    ' IMPORTANT 
    ' =======================================================================
    ' YOU NEED THIS ON ONE OF YOUR FORMS, TO LISTEN FOR GLOBAL HOTKEY PRESSES 
    ' =======================================================================
    ' Override WndProc to listen for hotkey presses Outside the Form Globally (while app is running at least)
    Protected Overrides Sub WndProc(ByRef m As Message)
        If m.Msg = WM_HOTKEY Then
            Dim id As Integer = m.WParam.ToInt32()
            If hotkeyIdMap.ContainsKey(id) Then
                hotkeyIdMap(id).Invoke()
            End If
        End If
        MyBase.WndProc(m)
    End Sub



    ' =========================
    ' FORM LOAD 
    ' =========================
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mainFormReference = Me

        ComboBox_CharacterKey.Sorted = True

        Try
            If ComboBox_CharacterKey.Items.Count > 11 Then
                ComboBox_CharacterKey.SelectedIndex = 11
            ElseIf ComboBox_CharacterKey.Items.Count > 0 Then
                ComboBox_CharacterKey.SelectedIndex = 0
            Else
                ComboBox_CharacterKey.SelectedIndex = -1
            End If
        Catch ex As Exception
            ComboBox_CharacterKey.SelectedIndex = -1
        End Try

        Try
            ' Populate function list
            If actionDict.Keys.Count > 0 Then
                ComboBox_FunctionList.Items.AddRange(actionDict.Keys.ToArray())
                ComboBox_FunctionList.Sorted = True
                ComboBox_FunctionList.SelectedIndex = -1
            End If
        Catch ex As Exception
            ComboBox_FunctionList.SelectedIndex = -1
        End Try
    End Sub





    Private Async Sub Button_ExportHotKeys_Click(sender As Object, e As EventArgs) Handles Button_ExportHotKeys.Click
        If DataGridView_HotKeys.Rows.Count > 0 Then
            Dim sfd As New SaveFileDialog With {.Filter = "JSON Files|*.json"}
            If sfd.ShowDialog() = DialogResult.OK Then
                If CheckBox_BackupToAutoData.Checked Then
                    Await ExportHotkeysAsync(DataGridView_HotKeys.Rows, sfd.FileName)
                End If
                MessageBox.Show("Hotkeys exported successfully.", "Export Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("No HotKeys to Export" & vbCrLf & "Import, or create some first.", "Nothing to Export", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub



    Private Async Sub Button_ImportHotKeys_Click(sender As Object, e As EventArgs) Handles Button_ImportHotKeys.Click
        Await ImportHotkeysAsync(
            owner:=Me,
            actionDict:=actionDict,
            hotKeyToAssign:=Sub(mods As Keys, key As Keys, act As Action)
                                AssignHotkey(ComboBox_FunctionList, DataGridView_HotKeys, mainFormReference, mods, key, act)
                            End Sub,
            dataGridRows:=DataGridView_HotKeys.Rows
        )
        If CheckBox_BackupToAutoData.Checked Then
            Await ExportHotkeysAsync(DataGridView_HotKeys.Rows)
        End If
    End Sub






    Private Sub CheckBox_BackupToAutoData_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_BackupToAutoData.CheckedChanged

    End Sub






    Private Sub ComboBox_FunctionList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_FunctionList.SelectedIndexChanged

    End Sub





    Private Sub CheckBox_ComboKey_Ctrl_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_ComboKey_Ctrl.CheckedChanged

    End Sub


    Private Sub CheckBox_ComboKey_Alt_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_ComboKey_Alt.CheckedChanged

    End Sub


    Private Sub CheckBox_ComboKey_Shift_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_ComboKey_Shift.CheckedChanged

    End Sub







    Private Sub ComboBox_CharacterKey_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_CharacterKey.SelectedIndexChanged

    End Sub







    Private Sub TextBox_FilterBox_TextChanged(sender As Object, e As EventArgs) Handles TextBox_FilterBox.TextChanged

    End Sub

    Private Sub TextBox_FilterBox_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox_FilterBox.KeyUp
        FilterDataGridView(DataGridView_HotKeys, TextBox_FilterBox.Text, caseInsensitive:=True)
    End Sub



    Private Sub Button_FilterClear_Click(sender As Object, e As EventArgs) Handles Button_FilterClear.Click
        TextBox_FilterBox.Text = ""
        FilterDataGridView(DataGridView_HotKeys, TextBox_FilterBox.Text, caseInsensitive:=True)
    End Sub




    Private Async Sub Button_AssignHotKey_Click(sender As Object, e As EventArgs) Handles Button_AssignHotKey.Click

        If ComboBox_FunctionList.Text = "" Then
            MessageBox.Show("Please select a Function/Action to assign to the Hot Key")
            Return
        End If
        Dim keyText As String = ComboBox_CharacterKey.Text.ToUpper()

        Dim selectedKey As Keys

        If Char.IsDigit(keyText(0)) Then
            ' Convert "1" to "D1"
            Try
                selectedKey = CType([Enum].Parse(GetType(Keys), "D" & keyText, True), Keys)
            Catch ex As Exception
                MessageBox.Show($"Error 000001 Invalid key selected: {keyText}", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End Try
        Else
            Dim keyMap As New Dictionary(Of String, Keys) From {
                {"_NUMPAD0", Keys.NumPad0}, {"_NUMPAD1", Keys.NumPad1}, {"_NUMPAD2", Keys.NumPad2},
                {"_NUMPAD3", Keys.NumPad3}, {"_NUMPAD4", Keys.NumPad4}, {"_NUMPAD5", Keys.NumPad5},
                {"_NUMPAD6", Keys.NumPad6}, {"_NUMPAD7", Keys.NumPad7}, {"_NUMPAD8", Keys.NumPad8},
                {"_NUMPAD9", Keys.NumPad9}
            }

            If keyMap.ContainsKey(keyText) Then
                selectedKey = keyMap(keyText)
            ElseIf Char.IsDigit(keyText(0)) Then
                Try
                    selectedKey = CType([Enum].Parse(GetType(Keys), "D" & keyText), Keys)
                Catch ex As Exception
                    MessageBox.Show($"Error 000002 Invalid key selected: {keyText}", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End Try
            Else
                Try
                    selectedKey = CType([Enum].Parse(GetType(Keys), keyText, True), Keys)
                Catch ex As Exception
                    MessageBox.Show($"Error 000003 Invalid key selected: {keyText}", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End Try
            End If
        End If

        Dim modifiers As Keys = Keys.None
        If CheckBox_ComboKey_Ctrl.Checked Then modifiers = modifiers Or Keys.Control
        If CheckBox_ComboKey_Alt.Checked Then modifiers = modifiers Or Keys.Alt
        If CheckBox_ComboKey_Shift.Checked Then modifiers = modifiers Or Keys.Shift

        Dim selectedAction As Action = actionDict(ComboBox_FunctionList.Text)

        AssignHotkey(ComboBox_FunctionList, DataGridView_HotKeys, mainFormReference, modifiers, selectedKey, selectedAction)
        DataGridHotKeysSelectionChanged()

        ' Auto Save
        If CheckBox_BackupToAutoData.Checked Then
            Await ExportHotkeysAsync(DataGridView_HotKeys.Rows)
        End If
    End Sub






    Private Sub Button_DeleteHotKeyRow_Click(sender As Object, e As EventArgs) Handles Button_DeleteHotKeyRow.Click
        If DataGridView_HotKeys.SelectedRows.Count = 0 Then Return

        Dim row = DataGridView_HotKeys.SelectedRows(0)
        'Dim comboText = row.Cells("KeyCombination").Value?.ToString()
        Dim funcName = row.Cells("ActionFunction").Value?.ToString()

        Dim action = actionDict(funcName)

        ' Unregister the hotkey
        If functionToHotkeyMap.ContainsKey(action) Then
            Dim hotkey = functionToHotkeyMap(action)
            Dim hotkeyId = hotkeyIdMap.FirstOrDefault(Function(kvp) kvp.Value = action).Key

            If hotkeyId <> 0 Then
                ' V1
                'NativeMethods.UnregisterHotKey(Me.Handle, hotkeyId)

                ' V2 withtry catch
                Try
                    NativeMethods.UnregisterHotKey(Me.Handle, hotkeyId)
                Catch ex As Exception
                    MessageBox.Show($"Failed to unregister hotkey with ID: {hotkeyId}.{vbCrLf}{ex.Message}", "Hotkey Unregistration Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End Try

                hotkeyIdMap.Remove(hotkeyId)
            End If

            functionToHotkeyMap.Remove(action)
            HotkeyMap.Remove(hotkey)
            Debug.WriteLine($"Unregistered Hotkey: {hotkey.Key} --- For Function: {action.Method}")
        End If

        DataGridView_HotKeys.Rows.Remove(row)
    End Sub








    Private Sub DataGridView_HotKeys_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_HotKeys.CellContentClick

    End Sub

    Private Sub DataGridView_HotKeys_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_HotKeys.CellClick
        DataGridHotKeysSelectionChanged()
    End Sub

    Private Sub DataGridView_HotKeys_SelectionChanged(sender As Object, e As EventArgs) Handles DataGridView_HotKeys.SelectionChanged
        DataGridHotKeysSelectionChanged()
    End Sub



    Private Sub DataGridHotKeysSelectionChanged()
        If DataGridView_HotKeys.SelectedRows.Count = 0 Then Return

        Dim row = DataGridView_HotKeys.SelectedRows(0)

        ComboBox_FunctionList.Text = row.Cells("ActionFunction").Value?.ToString()

        Dim comboParts = row.Cells("KeyCombination").Value?.ToString().Split(" + ").ToList()

        ' Reset checkboxes
        CheckBox_ComboKey_Ctrl.Checked = comboParts.Contains("Ctrl")
        CheckBox_ComboKey_Alt.Checked = comboParts.Contains("Alt")
        CheckBox_ComboKey_Shift.Checked = comboParts.Contains("Shift")

        Dim keyPart As String = comboParts.LastOrDefault()
        If String.IsNullOrEmpty(keyPart) Then Return

        ' Convert keyPart to Keys enum value (forward mapping)
        Dim selectedKey As Keys
        If keyPart.StartsWith("_NUMPAD") Then
            Dim num = keyPart.Substring(8)
            If Integer.TryParse(num, Nothing) Then
                Try
                    selectedKey = CType(Keys.NumPad0 + CInt(num), Keys)
                Catch ex As Exception
                    MessageBox.Show($"Error 000004 Invalid key selected:", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End Try

            End If
        ElseIf Char.IsDigit(keyPart(0)) Then
            Try
                selectedKey = CType([Enum].Parse(GetType(Keys), "D" & keyPart), Keys)
            Catch ex As Exception
                MessageBox.Show($"Error 000005 Invalid key selected:", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End Try

        Else
            Try
                selectedKey = CType([Enum].Parse(GetType(Keys), keyPart, True), Keys)
            Catch ex As Exception
                MessageBox.Show($"Error 000006 Invalid key selected:", "Key Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End Try

        End If

        ' Now reverse map the Keys value back to a ComboBox item (for setting UI)
        Dim keyText As String
        If selectedKey >= Keys.NumPad0 AndAlso selectedKey <= Keys.NumPad9 Then
            keyText = "_NUMPAD" & (selectedKey - Keys.NumPad0).ToString()
        ElseIf selectedKey >= Keys.D0 AndAlso selectedKey <= Keys.D9 Then
            keyText = (selectedKey - Keys.D0).ToString()
        Else
            keyText = selectedKey.ToString().ToLower()
        End If

        ComboBox_CharacterKey.Text = keyText
    End Sub



    Private Async Sub DataGridView_HotKeys_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_HotKeys.CellValueChanged
        Try
            Dim toggleCol = DataGridView_HotKeys.Columns("toggleHotkey")
            If toggleCol Is Nothing Then Return

            If e.ColumnIndex = toggleCol.Index AndAlso e.RowIndex >= 0 Then
                Dim row = DataGridView_HotKeys.Rows(e.RowIndex)
                Dim funcName = row.Cells("ActionFunction").Value?.ToString()
                Dim isEnabled = CBool(row.Cells("toggleHotkey").Value)

                If Not String.IsNullOrEmpty(funcName) AndAlso actionDict.ContainsKey(funcName) Then
                    Dim action = actionDict(funcName)
                    Sub_ToggleHotkey(Me, action, isEnabled)
                End If
            End If
        Catch ex As Exception
            Debug.WriteLine(ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
        End Try

        ' AutoSave 
        If CheckBox_BackupToAutoData.Checked Then
            If e.RowIndex >= 0 Then
                ' Only auto-save if user changed a relevant column
                Dim colName = DataGridView_HotKeys.Columns(e.ColumnIndex).Name
                If {"ActionFunction", "KeyCombination", "toggleHotkey"}.Contains(colName) Then
                    Await ExportHotkeysAsync(DataGridView_HotKeys.Rows)
                End If
            End If
        End If
    End Sub


    Private Sub DataGridView_HotKeys_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles DataGridView_HotKeys.CurrentCellDirtyStateChanged
        If DataGridView_HotKeys.IsCurrentCellDirty Then
            DataGridView_HotKeys.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub


    Private Async Sub DataGridView_HotKeys_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DataGridView_HotKeys.RowsRemoved
        ' AutoSave 
        If CheckBox_BackupToAutoData.Checked Then
            Await ExportHotkeysAsync(DataGridView_HotKeys.Rows)
        End If
    End Sub




    Private Sub Button_About_Click(sender As Object, e As EventArgs) Handles Button_About.Click
        MessageBox.Show(hotKeys_aboutText, "About Hotkey Manager", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub





    ' =========================
    ' FORM CLOSE 
    ' =========================

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
        ' Unregister Hot Keys
        For Each id In hotkeyIdMap.Keys
            NativeMethods.UnregisterHotKey(Me.Handle, id)
        Next
        MyBase.OnFormClosing(e)
    End Sub



End Class
