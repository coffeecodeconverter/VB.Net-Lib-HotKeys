﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox_CharacterKey = New System.Windows.Forms.ComboBox()
        Me.Button_AssignHotKey = New System.Windows.Forms.Button()
        Me.ComboBox_FunctionList = New System.Windows.Forms.ComboBox()
        Me.CheckBox_ComboKey_Ctrl = New System.Windows.Forms.CheckBox()
        Me.CheckBox_ComboKey_Alt = New System.Windows.Forms.CheckBox()
        Me.CheckBox_ComboKey_Shift = New System.Windows.Forms.CheckBox()
        Me.DataGridView_HotKeys = New System.Windows.Forms.DataGridView()
        Me.ActionFunction = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KeyCombination = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.toggleHotkey = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Button_DeleteHotKeyRow = New System.Windows.Forms.Button()
        Me.Button_ExportHotKeys = New System.Windows.Forms.Button()
        Me.Button_ImportHotKeys = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button_About = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button_FilterClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox_FilterBox = New System.Windows.Forms.TextBox()
        Me.CheckBox_BackupToAutoData = New System.Windows.Forms.CheckBox()
        Me.Button_AppDirectory = New System.Windows.Forms.Button()
        CType(Me.DataGridView_HotKeys, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBox_CharacterKey
        '
        Me.ComboBox_CharacterKey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_CharacterKey.FormattingEnabled = True
        Me.ComboBox_CharacterKey.Items.AddRange(New Object() {"_numpad0", "_numpad1", "_numpad2", "_numpad3", "_numpad4", "_numpad5", "_numpad6", "_numpad7", "_numpad8", "_numpad9", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "b", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "space", "t", "u", "w", "y"})
        Me.ComboBox_CharacterKey.Location = New System.Drawing.Point(89, 147)
        Me.ComboBox_CharacterKey.Name = "ComboBox_CharacterKey"
        Me.ComboBox_CharacterKey.Size = New System.Drawing.Size(87, 21)
        Me.ComboBox_CharacterKey.Sorted = True
        Me.ComboBox_CharacterKey.TabIndex = 8
        '
        'Button_AssignHotKey
        '
        Me.Button_AssignHotKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_AssignHotKey.Location = New System.Drawing.Point(304, 146)
        Me.Button_AssignHotKey.Name = "Button_AssignHotKey"
        Me.Button_AssignHotKey.Size = New System.Drawing.Size(59, 23)
        Me.Button_AssignHotKey.TabIndex = 9
        Me.Button_AssignHotKey.Text = "Update"
        Me.Button_AssignHotKey.UseVisualStyleBackColor = True
        '
        'ComboBox_FunctionList
        '
        Me.ComboBox_FunctionList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_FunctionList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FunctionList.FormattingEnabled = True
        Me.ComboBox_FunctionList.Location = New System.Drawing.Point(89, 103)
        Me.ComboBox_FunctionList.Name = "ComboBox_FunctionList"
        Me.ComboBox_FunctionList.Size = New System.Drawing.Size(274, 21)
        Me.ComboBox_FunctionList.TabIndex = 4
        '
        'CheckBox_ComboKey_Ctrl
        '
        Me.CheckBox_ComboKey_Ctrl.AutoSize = True
        Me.CheckBox_ComboKey_Ctrl.Location = New System.Drawing.Point(90, 128)
        Me.CheckBox_ComboKey_Ctrl.Name = "CheckBox_ComboKey_Ctrl"
        Me.CheckBox_ComboKey_Ctrl.Size = New System.Drawing.Size(41, 17)
        Me.CheckBox_ComboKey_Ctrl.TabIndex = 5
        Me.CheckBox_ComboKey_Ctrl.Text = "Ctrl"
        Me.CheckBox_ComboKey_Ctrl.UseVisualStyleBackColor = True
        '
        'CheckBox_ComboKey_Alt
        '
        Me.CheckBox_ComboKey_Alt.AutoSize = True
        Me.CheckBox_ComboKey_Alt.Location = New System.Drawing.Point(139, 128)
        Me.CheckBox_ComboKey_Alt.Name = "CheckBox_ComboKey_Alt"
        Me.CheckBox_ComboKey_Alt.Size = New System.Drawing.Size(38, 17)
        Me.CheckBox_ComboKey_Alt.TabIndex = 6
        Me.CheckBox_ComboKey_Alt.Text = "Alt"
        Me.CheckBox_ComboKey_Alt.UseVisualStyleBackColor = True
        '
        'CheckBox_ComboKey_Shift
        '
        Me.CheckBox_ComboKey_Shift.AutoSize = True
        Me.CheckBox_ComboKey_Shift.Location = New System.Drawing.Point(186, 128)
        Me.CheckBox_ComboKey_Shift.Name = "CheckBox_ComboKey_Shift"
        Me.CheckBox_ComboKey_Shift.Size = New System.Drawing.Size(47, 17)
        Me.CheckBox_ComboKey_Shift.TabIndex = 7
        Me.CheckBox_ComboKey_Shift.Text = "Shift"
        Me.CheckBox_ComboKey_Shift.UseVisualStyleBackColor = True
        '
        'DataGridView_HotKeys
        '
        Me.DataGridView_HotKeys.AllowUserToAddRows = False
        Me.DataGridView_HotKeys.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_HotKeys.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_HotKeys.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ActionFunction, Me.KeyCombination, Me.toggleHotkey})
        Me.DataGridView_HotKeys.Location = New System.Drawing.Point(7, 231)
        Me.DataGridView_HotKeys.Name = "DataGridView_HotKeys"
        Me.DataGridView_HotKeys.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_HotKeys.Size = New System.Drawing.Size(361, 295)
        Me.DataGridView_HotKeys.TabIndex = 12
        '
        'ActionFunction
        '
        Me.ActionFunction.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ActionFunction.HeaderText = "Action"
        Me.ActionFunction.Name = "ActionFunction"
        Me.ActionFunction.ReadOnly = True
        Me.ActionFunction.Width = 62
        '
        'KeyCombination
        '
        Me.KeyCombination.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.KeyCombination.HeaderText = "HotKey"
        Me.KeyCombination.Name = "KeyCombination"
        Me.KeyCombination.ReadOnly = True
        Me.KeyCombination.Width = 67
        '
        'toggleHotkey
        '
        Me.toggleHotkey.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.toggleHotkey.HeaderText = "Enabled"
        Me.toggleHotkey.Name = "toggleHotkey"
        '
        'Button_DeleteHotKeyRow
        '
        Me.Button_DeleteHotKeyRow.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_DeleteHotKeyRow.Location = New System.Drawing.Point(309, 532)
        Me.Button_DeleteHotKeyRow.Name = "Button_DeleteHotKeyRow"
        Me.Button_DeleteHotKeyRow.Size = New System.Drawing.Size(59, 23)
        Me.Button_DeleteHotKeyRow.TabIndex = 14
        Me.Button_DeleteHotKeyRow.Text = "Delete"
        Me.Button_DeleteHotKeyRow.UseVisualStyleBackColor = True
        '
        'Button_ExportHotKeys
        '
        Me.Button_ExportHotKeys.Location = New System.Drawing.Point(9, 9)
        Me.Button_ExportHotKeys.Name = "Button_ExportHotKeys"
        Me.Button_ExportHotKeys.Size = New System.Drawing.Size(85, 23)
        Me.Button_ExportHotKeys.TabIndex = 1
        Me.Button_ExportHotKeys.Text = "Export"
        Me.Button_ExportHotKeys.UseVisualStyleBackColor = True
        '
        'Button_ImportHotKeys
        '
        Me.Button_ImportHotKeys.Location = New System.Drawing.Point(96, 9)
        Me.Button_ImportHotKeys.Name = "Button_ImportHotKeys"
        Me.Button_ImportHotKeys.Size = New System.Drawing.Size(85, 23)
        Me.Button_ImportHotKeys.TabIndex = 2
        Me.Button_ImportHotKeys.Text = "Import"
        Me.Button_ImportHotKeys.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Function"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Combo Key(s)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Character Key"
        '
        'Button_About
        '
        Me.Button_About.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_About.Location = New System.Drawing.Point(7, 531)
        Me.Button_About.Name = "Button_About"
        Me.Button_About.Size = New System.Drawing.Size(58, 23)
        Me.Button_About.TabIndex = 13
        Me.Button_About.Text = "About"
        Me.Button_About.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel1.Controls.Add(Me.Button_FilterClear)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.TextBox_FilterBox)
        Me.Panel1.Location = New System.Drawing.Point(7, 202)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(361, 30)
        Me.Panel1.TabIndex = 17
        '
        'Button_FilterClear
        '
        Me.Button_FilterClear.ForeColor = System.Drawing.Color.Red
        Me.Button_FilterClear.Location = New System.Drawing.Point(172, 4)
        Me.Button_FilterClear.Name = "Button_FilterClear"
        Me.Button_FilterClear.Size = New System.Drawing.Size(27, 23)
        Me.Button_FilterClear.TabIndex = 11
        Me.Button_FilterClear.Text = "X"
        Me.Button_FilterClear.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Filter"
        '
        'TextBox_FilterBox
        '
        Me.TextBox_FilterBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox_FilterBox.Location = New System.Drawing.Point(41, 5)
        Me.TextBox_FilterBox.Name = "TextBox_FilterBox"
        Me.TextBox_FilterBox.Size = New System.Drawing.Size(130, 20)
        Me.TextBox_FilterBox.TabIndex = 10
        '
        'CheckBox_BackupToAutoData
        '
        Me.CheckBox_BackupToAutoData.AutoSize = True
        Me.CheckBox_BackupToAutoData.Checked = True
        Me.CheckBox_BackupToAutoData.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_BackupToAutoData.Location = New System.Drawing.Point(12, 38)
        Me.CheckBox_BackupToAutoData.Name = "CheckBox_BackupToAutoData"
        Me.CheckBox_BackupToAutoData.Size = New System.Drawing.Size(167, 17)
        Me.CheckBox_BackupToAutoData.TabIndex = 3
        Me.CheckBox_BackupToAutoData.Text = "Auto-Backup to App Directory"
        Me.CheckBox_BackupToAutoData.UseVisualStyleBackColor = True
        '
        'Button_AppDirectory
        '
        Me.Button_AppDirectory.Location = New System.Drawing.Point(9, 58)
        Me.Button_AppDirectory.Name = "Button_AppDirectory"
        Me.Button_AppDirectory.Size = New System.Drawing.Size(85, 23)
        Me.Button_AppDirectory.TabIndex = 18
        Me.Button_AppDirectory.Text = "App Dir"
        Me.Button_AppDirectory.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(373, 561)
        Me.Controls.Add(Me.Button_AppDirectory)
        Me.Controls.Add(Me.CheckBox_BackupToAutoData)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button_About)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button_ImportHotKeys)
        Me.Controls.Add(Me.Button_ExportHotKeys)
        Me.Controls.Add(Me.Button_DeleteHotKeyRow)
        Me.Controls.Add(Me.DataGridView_HotKeys)
        Me.Controls.Add(Me.CheckBox_ComboKey_Shift)
        Me.Controls.Add(Me.CheckBox_ComboKey_Alt)
        Me.Controls.Add(Me.CheckBox_ComboKey_Ctrl)
        Me.Controls.Add(Me.ComboBox_FunctionList)
        Me.Controls.Add(Me.Button_AssignHotKey)
        Me.Controls.Add(Me.ComboBox_CharacterKey)
        Me.MinimumSize = New System.Drawing.Size(270, 400)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Assign Hotkeys"
        CType(Me.DataGridView_HotKeys, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox_CharacterKey As ComboBox
    Friend WithEvents Button_AssignHotKey As Button
    Friend WithEvents ComboBox_FunctionList As ComboBox
    Friend WithEvents CheckBox_ComboKey_Ctrl As CheckBox
    Friend WithEvents CheckBox_ComboKey_Alt As CheckBox
    Friend WithEvents CheckBox_ComboKey_Shift As CheckBox
    Friend WithEvents DataGridView_HotKeys As DataGridView
    Friend WithEvents Button_DeleteHotKeyRow As Button
    Friend WithEvents Button_ExportHotKeys As Button
    Friend WithEvents Button_ImportHotKeys As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button_About As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox_FilterBox As TextBox
    Friend WithEvents Button_FilterClear As Button
    Friend WithEvents CheckBox_BackupToAutoData As CheckBox
    Friend WithEvents ActionFunction As DataGridViewTextBoxColumn
    Friend WithEvents KeyCombination As DataGridViewTextBoxColumn
    Friend WithEvents toggleHotkey As DataGridViewCheckBoxColumn
    Friend WithEvents Button_AppDirectory As Button
End Class
